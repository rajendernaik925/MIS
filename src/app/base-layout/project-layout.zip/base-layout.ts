import { Component } from '@angular/core';
import { Header } from './header/header';
import { RouterModule } from '@angular/router';
import { Sidebar } from './sidebar/sidebar';

@Component({
  selector: 'app-base-layout',
  imports: [
    Header,
    RouterModule,
    Sidebar,
  ],
  templateUrl: './base-layout.html',
  styleUrl: './base-layout.scss',
})
export class BaseLayout {
  pageTitle = 'Executive Overview';
  payPeriod = 'Pay Period 202607';
  sidebarCollapsed = false;

  onSidebarToggle(collapsed: boolean): void {
    this.sidebarCollapsed = collapsed;
  }

  onLocationChange(value: string): void {
    // TODO: wire this into your shared filter/CoreService so every
    // routed view (dashboard, payable summary, etc.) can react to it.
    console.log('Location filter changed:', value);
  }

  onLogout(): void {
    // TODO: clear auth/session state via your auth service, then redirect
    // e.g. this.authService.logout(); this.router.navigate(['/login']);
    console.log('Logout requested');
  }
}
