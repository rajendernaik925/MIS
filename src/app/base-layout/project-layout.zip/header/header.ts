import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CoreService } from '../../core/services/core.services';

@Component({
  selector: 'app-header',
  imports: [FormsModule],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header {
  private coreService = inject(CoreService);

  @Input() pageTitle = 'Executive Overview';
  @Input() payPeriod = 'Pay Period 202607';
  @Output() locationChange = new EventEmitter<string>();

  selectedLocation = 'ALL';

  onFilterChange(): void {
    this.locationChange.emit(this.selectedLocation);
  }
}
